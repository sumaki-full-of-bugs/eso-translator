local function OnPlayerActivated(eventCode, initial)
    -- チャットログを強制的にONにする
    SetChatLogEnabled(true)
    
    -- initialがtrueの場合（ログイン・リロード直後）のみメッセージを表示
    if initial then
        d("|cFFFF00AutoChatLog:|r チャットログの出力をONにしました。")
    end
end

-- 登録済みのイベントを念のため解除してから再登録
EVENT_MANAGER:UnregisterForEvent("AutoChatLog", EVENT_PLAYER_ACTIVATED)
EVENT_MANAGER:RegisterForEvent("AutoChatLog", EVENT_PLAYER_ACTIVATED, OnPlayerActivated)